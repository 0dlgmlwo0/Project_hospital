package com.hospital.service;

import com.hospital.client.ProDocApiCaller;
import com.hospital.dto.api.ProDocApiResponse;
import com.hospital.entity.ProDoc;
import com.hospital.parser.ProDocApiParser;
import com.hospital.repository.ProDocRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProDocServiceImpl implements ProDocService {

    private final ProDocApiCaller apiCaller;
    private final ProDocApiParser parser;
    private final ProDocRepository repository;
    private final HospitalCodeFetcher hospitalCodeFetcher;

    @Autowired
    public ProDocServiceImpl(ProDocApiCaller apiCaller,
                             ProDocApiParser parser,
                             ProDocRepository repository,
                             HospitalCodeFetcher hospitalCodeFetcher) {
        this.apiCaller = apiCaller;
        this.parser = parser;
        this.repository = repository;
        this.hospitalCodeFetcher = hospitalCodeFetcher;
    }

    @Override
    public int fetchParseAndSaveProDocs() {
        int totalSaved = 0;

        List<String> hospitalCodes = hospitalCodeFetcher.getAllHospitalCodes();

        for (String hospitalCode : hospitalCodes) {
            String queryParams = String.format("ykiho=%s", hospitalCode);

            try {
                ProDocApiResponse response = apiCaller.callApi("getSpcSbjtSdrInfo2.7", queryParams);
                List<ProDoc> parsed = parser.parse(response, hospitalCode); 


                if (!parsed.isEmpty()) {
                    repository.saveAll(parsed);
                    totalSaved += parsed.size();
                }

                Thread.sleep(3000); // API 요청 간격 조절

            } catch (Exception e) {
                System.err.println("병원코드 " + hospitalCode + " 에서 오류 발생: " + e.getMessage());
            }
        }

        return totalSaved;
    }
}
