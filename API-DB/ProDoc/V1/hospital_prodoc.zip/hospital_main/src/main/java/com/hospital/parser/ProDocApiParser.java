package com.hospital.parser;

import com.hospital.dto.api.ProDocApiItem;
import com.hospital.dto.api.ProDocApiResponse;
import com.hospital.entity.ProDoc;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ProDocApiParser {

    public List<ProDoc> parse(ProDocApiResponse response, String hospitalCode) {
        List<ProDoc> result = new ArrayList<>();

        if (response == null ||
            response.getResponse() == null ||
            response.getResponse().getBody() == null ||
            response.getResponse().getBody().getItems() == null ||
            response.getResponse().getBody().getItems().getItem() == null) {
            return result;
        }

        List<ProDocApiItem> items = response.getResponse().getBody().getItems().getItem();

        for (ProDocApiItem item : items) {
            ProDoc entity = new ProDoc();
            entity.setHospitalCode(hospitalCode); // 병원 코드 주입
            entity.setSubjectName(item.getSubjectName());
            entity.setProDocCount(item.getProDocCount());
            result.add(entity);
        }

        return result;
    }
}
