package com.hospital.controller;

import com.hospital.service.ProDocService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/prodoc")
public class ProDocController {

    private final ProDocService proDocService;

    @Autowired
    public ProDocController(ProDocService proDocService) {
        this.proDocService = proDocService;
    }

    // 브라우저에서도 동작하도록 GET 방식으로 설정
    @GetMapping("/save")
    public String syncProDocData() {
        int savedCount = proDocService.fetchParseAndSaveProDocs();
        return "전문의 데이터 " + savedCount + "개 저장 완료!";
    }
}
