package com.hospital.service;

public interface ProDocService {
    int fetchParseAndSaveProDocs();
}
