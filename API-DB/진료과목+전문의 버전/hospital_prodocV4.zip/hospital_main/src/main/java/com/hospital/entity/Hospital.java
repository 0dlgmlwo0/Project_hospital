package com.hospital.entity;

// JPA 관련 임포트
import jakarta.persistence.*;
import java.util.List; // ✅ 관계 설정용 List

// Lombok 어노테이션
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "hospital_main")
public class Hospital {

    @Id
    @Column(name = "hospital_code", nullable = false, length = 255)
    private String hospitalCode;

    @Column(name = "hospital_name", nullable = false, length = 255)
    private String hospitalName;

    @Column(name = "province_name", length = 100)
    private String provinceName;

    @Column(name = "district_name", length = 100)
    private String districtName;

    @Column(name = "hospital_address", length = 500)
    private String hospitalAddress;

    @Column(name = "hospital_tel", length = 20)
    private String hospitalTel;

    @Column(name = "hospital_homepage", length = 255)
    private String hospitalHomepage;

    @Column(name = "doctor_num")
    private int doctorNum;

    @Column(name = "coordinate_x")
    private double coordinateX;

    @Column(name = "coordinate_y")
    private double coordinateY;

    // ================================
    // ✅ 관계 설정 추가
    // ================================

    @OneToOne(mappedBy = "hospital", cascade = CascadeType.ALL)
    private HospitalDetail hospitalDetail;

    @OneToMany(mappedBy = "hospital", cascade = CascadeType.ALL)
    private List<ProDoc> proDocs;

    @OneToMany(mappedBy = "hospital", cascade = CascadeType.ALL)
    private List<MedicalSubject> medicalSubjects;
}
