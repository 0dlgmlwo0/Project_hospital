package com.hospital.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 🏥 HospitalCodeFetcher
 * 병원 코드(hospital_code)를 DB에서 직접 조회하는 서비스 클래스
 */
@Service
public class HospitalCodeFetcher {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public HospitalCodeFetcher(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * ✅ 병원 전체 hospital_code 리스트 반환
     * hospital_main 테이블에서 모든 병원코드를 조회함
     *
     * @return 병원 코드 리스트 (List<String>)
     */
    public List<String> getAllHospitalCodes() {
        String sql = "SELECT hospital_code FROM hospital_main";
        return jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("hospital_code"));
    }
}
