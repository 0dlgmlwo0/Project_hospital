// 📁 ProDocAsyncRunner.java
package com.hospital.async;

import com.hospital.client.ProDocApiCaller;
import com.hospital.dto.api.ProDocApiResponse;
import com.hospital.entity.ProDoc;
import com.hospital.parser.ProDocApiParser;
import com.hospital.repository.ProDocRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Service
public class ProDocAsyncRunner {

    private final ProDocApiCaller apiCaller;
    private final ProDocApiParser parser;
    private final ProDocRepository repository;

    private final AtomicInteger completedCount = new AtomicInteger(0);
    private final AtomicInteger failedCount = new AtomicInteger(0);
    private int totalCount = 0;

    @Autowired
    public ProDocAsyncRunner(ProDocApiCaller apiCaller,
                              ProDocApiParser parser,
                              ProDocRepository repository) {
        this.apiCaller = apiCaller;
        this.parser = parser;
        this.repository = repository;
    }
    
    public void resetCounter() {
        completedCount.set(0);
        failedCount.set(0);
    }


    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
        completedCount.set(0);
        failedCount.set(0);
    }

    public int getCompletedCount() {
        return completedCount.get();
    }

    public int getFailedCount() {
        return failedCount.get();
    }

    @Async("proDocExecutor")
    public void runAsync(String hospitalCode) {
        try {
            String queryParams = String.format("ykiho=%s", hospitalCode);
            ProDocApiResponse response = apiCaller.callApi("getSpcSbjtSdrInfo2.7", queryParams);
            List<ProDoc> parsed = parser.parse(response, hospitalCode);

            if (!parsed.isEmpty()) {
                repository.saveAll(parsed);
            }

            int done = completedCount.incrementAndGet();
            log.info("\u2705 처리됨: {} / {} ({}%)", done, totalCount, (done * 100) / totalCount);

        } catch (Exception e) {
            failedCount.incrementAndGet();
            log.error("\u274C 병원코드 {} 처리 중 오류: {}", hospitalCode, e.getMessage());
        }
    }
}
