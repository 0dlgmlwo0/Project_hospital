package com.hospital.controller;

import com.hospital.service.ProDocService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/prodoc") 
public class ProDocController {

    private final ProDocService proDocService;

    @Autowired
    public ProDocController(ProDocService proDocService) {
        this.proDocService = proDocService;
    }

    @GetMapping(value = "/save", produces = MediaType.TEXT_PLAIN_VALUE)
    public String syncProDocData() {
        int total = proDocService.fetchParseAndSaveProDocs();
        return String.format("전문의 정보 저장 시작됨! 전체 병원 수: %d개.\n(실시간 진행상황은 로그에서 확인 가능)\n", total);
    }

    @GetMapping(value = "/status", produces = MediaType.TEXT_PLAIN_VALUE)
    public String getStatus() {
        int done = proDocService.getCompletedCount();
        int fail = proDocService.getFailedCount();
        return String.format("현재 진행상황: 완료 %d건, 실패 %d건\n", done, fail);
    }
}
