package com.hospital.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HospitalCodeFetcher {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public HospitalCodeFetcher(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<String> getAllHospitalCodes() {
        String sql = "SELECT hospital_code FROM hospital_main";
        return jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("hospital_code"));
    }
}
	