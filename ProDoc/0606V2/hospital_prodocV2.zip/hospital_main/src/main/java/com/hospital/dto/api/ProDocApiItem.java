package com.hospital.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProDocApiItem {

    @JsonProperty("ykiho")
    private String hospitalCode;

    @JsonProperty("dgsbjtCdNm")
    private String subjectName;

    @JsonProperty("dtlSdrCnt")  
    private Integer proDocCount;
}
