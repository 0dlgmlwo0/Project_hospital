package com.hospital.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hospital.dto.api.ProDocApiResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ProDocApiCaller {

    private static final String BASE_URL = "https://apis.data.go.kr/B551182/MadmDtlInfoService2.7/";
    private static final String SERVICE_KEY = "TzaQUmy4fc/d/DHC1P4CuTojEFQfVTDolu1aol1Ex2KZl4NUT0guLiLeF6i0L645pR48XvVYcWCX28KPD4dzXA=="; 
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public ProDocApiCaller(ObjectMapper objectMapper) {
        this.restTemplate = new RestTemplate();
        this.objectMapper = objectMapper;
    }

    public ProDocApiResponse callApi(String apiPath, String queryParams) {
        try {
            String fullUrl = BASE_URL + apiPath + "?serviceKey=" + SERVICE_KEY + "&_type=json&" + queryParams;
            String response = restTemplate.getForObject(fullUrl, String.class);

            return objectMapper.readValue(response, ProDocApiResponse.class);

        } catch (Exception e) {
            throw new RuntimeException("ProDoc API 호출 중 오류 발생: " + e.getMessage(), e);
        }
    }
}
