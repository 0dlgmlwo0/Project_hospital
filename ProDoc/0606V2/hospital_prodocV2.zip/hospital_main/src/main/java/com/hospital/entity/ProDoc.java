package com.hospital.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "pro_doc")
public class ProDoc {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "hospital_code")
    private String hospitalCode;

    @Column(name = "subject_name")
    private String subjectName;

    @Column(name = "pro_doc_count")
    private Integer proDocCount;

    // 기본 생성자
    public ProDoc() {}

    // Getter & Setter
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getHospitalCode() { return hospitalCode; }
    public void setHospitalCode(String hospitalCode) { this.hospitalCode = hospitalCode; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public Integer getProDocCount() { return proDocCount; }
    public void setProDocCount(Integer proDocCount) { this.proDocCount = proDocCount; }
}
