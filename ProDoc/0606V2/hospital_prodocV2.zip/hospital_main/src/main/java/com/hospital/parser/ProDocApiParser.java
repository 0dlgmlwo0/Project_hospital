package com.hospital.parser;

import com.hospital.dto.api.ProDocApiItem;
import com.hospital.dto.api.ProDocApiResponse;
import com.hospital.entity.ProDoc;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ProDocApiParser {

    // 진료과목 분류용 Set
    private static final Set<String> DENTAL_SUBJECTS = Set.of(
        "치과", "치과교정과", "치과보존과", "치과보철과","치주과","영상치의학과",
        "소아치과", "예방치과", "구강내과", "구강병리과", "구강악안면외과","통합치의학과"
    );

    private static final Set<String> ORIENTAL_SUBJECTS = Set.of(
        "한방내과", "한방부인과", "한방소아과", "한방신경정신과",
        "한방안·이비인후·피부과", "한방재활의학과", "한방응급", "침구과", "사상체질과"
    );

    private static final Set<String> NEUROLOGY_SUBJECTS = Set.of(
        "신경과", "신경외과", "정신건강의학과"
    );

    public List<ProDoc> parse(ProDocApiResponse response, String hospitalCode) {
        if (response == null || response.getResponse() == null || response.getResponse().getBody() == null) {
            return List.of();
        }

        List<ProDoc> result = new ArrayList<>();
        List<ProDocApiItem> items = response.getResponse().getBody().getItems().getItem();

        if (items == null) return result;

        for (ProDocApiItem item : items) {
            String rawSubjectName = item.getSubjectName();
            Integer count = item.getProDocCount();

            String normalized = normalizeSubjectName(rawSubjectName);

            ProDoc doc = new ProDoc();
            doc.setHospitalCode(hospitalCode);
            doc.setSubjectName(normalized);
            doc.setProDocCount(count != null ? count : 0);

            result.add(doc);
        }

        return result;
    }

    // 과목명을 카테고리로 정규화
    private String normalizeSubjectName(String rawName) {
        if (rawName == null) return "알수없음";

        if (DENTAL_SUBJECTS.contains(rawName)) return "치과";
        if (ORIENTAL_SUBJECTS.contains(rawName)) return "한의원";
        if (NEUROLOGY_SUBJECTS.contains(rawName)) return "신경과";

        return rawName; // 정규화 안 된 건 원래 이름 유지
    }
}
