package com.hospital.service;

import com.hospital.async.ProDocAsyncRunner;
import com.hospital.repository.ProDocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProDocServiceImpl implements ProDocService {

    private final HospitalMainService hospitalMainService;
    private final ProDocAsyncRunner asyncRunner;
    private final ProDocRepository proDocRepository;

    @Autowired
    public ProDocServiceImpl(HospitalMainService hospitalMainService,
                             ProDocAsyncRunner asyncRunner,
                             ProDocRepository proDocRepository) {
        this.hospitalMainService = hospitalMainService;
        this.asyncRunner = asyncRunner;
        this.proDocRepository = proDocRepository;
    }

    @Override
    public int fetchParseAndSaveProDocs() {
        // ✅ 기존 데이터 전체 삭제
        proDocRepository.deleteAll();

        // 병원 코드 리스트 불러오기
        List<String> hospitalCodes = hospitalMainService.getAllHospitalCodes();

        // 비동기 상태 초기화
        asyncRunner.resetCounter();
        asyncRunner.setTotalCount(hospitalCodes.size());

        // 병원 코드별 API 호출
        for (String hospitalCode : hospitalCodes) {
            asyncRunner.runAsync(hospitalCode);
        }

        return hospitalCodes.size();
    }

    @Override
    public int getCompletedCount() {
        return asyncRunner.getCompletedCount();
    }

    @Override
    public int getFailedCount() {
        return asyncRunner.getFailedCount();
    }
}
