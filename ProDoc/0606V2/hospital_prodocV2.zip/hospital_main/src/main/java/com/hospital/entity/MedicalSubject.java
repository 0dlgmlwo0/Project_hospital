package com.hospital.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "medical_subject")
public class MedicalSubject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "hospital_code")
    private String hospitalCode;

    @Column(name = "subject_name")
    private String subjectName;

    // 기본 생성자
    public MedicalSubject() {}

    // Getter & Setter
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getHospitalCode() { return hospitalCode; }
    public void setHospitalCode(String hospitalCode) { this.hospitalCode = hospitalCode; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
}
