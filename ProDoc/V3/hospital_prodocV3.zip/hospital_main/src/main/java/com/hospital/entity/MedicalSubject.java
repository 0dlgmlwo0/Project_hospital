package com.hospital.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "medical_subject")
public class MedicalSubject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "hospital_code", nullable = false) // ✅ DB 저장용 외래키 필드
    private String hospitalCode;

    @Column(name = "subject_name")
    private String subjectName;

    // ✅ N:1 병원 관계 매핑 (참조용, 실제 저장은 hospitalCode가 담당)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
        name = "hospital_code",                // 내 테이블의 외래키 컬럼
        referencedColumnName = "hospital_code", // 병원 테이블의 PK
        insertable = false, updatable = false   // 병원 객체를 통해 hospital_code 직접 수정 못하게 막음
    )
    private Hospital hospital;

    // 기본 생성자
    public MedicalSubject() {}

    // Getter & Setter
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getHospitalCode() { return hospitalCode; }
    public void setHospitalCode(String hospitalCode) { this.hospitalCode = hospitalCode; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public Hospital getHospital() { return hospital; }
    public void setHospital(Hospital hospital) { this.hospital = hospital; }
}
